<?php

return [

'data' => '<b>:name</b> تیکت  "<b>:subject</b>" را به  :agent از دسته :old_category به شما در دسته in :new_category انتقال داده است<br>',

];
