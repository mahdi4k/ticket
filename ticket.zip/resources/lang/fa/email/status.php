<?php

return [

'data' => '<b>:name</b> وضعیت تیکت ":subject" را از :old_status به  :new_status تغییر داده است<br>',

];
