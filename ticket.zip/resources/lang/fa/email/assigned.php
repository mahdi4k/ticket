<?php

return [

'data' => '
	<b>:name</b> یک تیکت با موضوع <b>:subject</b> ایجاد کرده است<br>
	:status در :category, و این تیکت به شما ارجاع داده شده است.<br>
',

];
