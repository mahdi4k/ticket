<?php

return [

    'initial-setup'                   => 'تنظیمات اولیه',
    'master-template-file'            => 'نام فایل قالب (master template file)',
    'master-template-other-path'      => 'مسیر دیگر',
    'master-template-other-path-ex'   => 'ex. views/layouts/app.blade.php',
    'migrations-to-be-installed'      => 'میگریشن های زیر نصب شدند:',
    'all-tables-migrated'             => 'تمامی جداول مورد نیاز بازسازی شدند',
    'proceed'                         => 'Proceed',
    'another-file'                    => 'فایل دیگر',
    'admin-select'                    => 'انتخاب مدیر', // New
    'admin-select-help-block'         => 'شما بعدا میتوانید مدیر های دیگری نیز اضافه نمایید', // New
    'upgrade'                         => 'Ticketit version upgrade', // New v0.2.3
    'settings-to-be-installed'        => 'تنظیمات زیر به جدول تنظیمات اضافه شدند:', // New v0.2.3
    'all-settings-installed'          => 'تمامی تنظیمات مورد نیاز برنامه اعمال گردید', // New v0.2.3
];
