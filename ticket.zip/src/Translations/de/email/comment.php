<?php

return [

'data' => '
	<b>:name</b> hat einen Kommentar hinterlassen: <b>:subject</b><br>
	<b>Ticket Kategorie:</b> :category - <b>Status:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];
