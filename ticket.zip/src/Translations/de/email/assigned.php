<?php

return [

'data' => '
	<b>:name</b> hat ein neues Ticket erstellt <b>:subject</b><br>
	:status in :category, welches Dir zugewiesen wurde.<br>
',

];
