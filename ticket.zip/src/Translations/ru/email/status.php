<?php

return [

'data' => '<b>:name</b> изменил статус тикета ":subject" с :old_status на :new_status<br>',

];
