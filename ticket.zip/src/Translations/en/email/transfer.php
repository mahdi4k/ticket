<?php

return [

'data' => '<b>:name</b> has transferred the ticket "<b>:subject</b>" from :agent in :old_category to you in :new_category<br>',

];
