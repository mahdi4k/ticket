<?php

return [

'data' => '<b>:name</b> changed the status of ":subject" from :old_status to :new_status<br>',

];
