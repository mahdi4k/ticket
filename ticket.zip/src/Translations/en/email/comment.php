<?php

return [

'data' => '
	<b>:name</b> commented on ticket: <b>:subject</b><br>
	<b>Ticket category:</b> :category - <b>status:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];
