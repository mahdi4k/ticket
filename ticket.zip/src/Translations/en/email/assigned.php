<?php

return [

'data' => '
	<b>:name</b> created new ticket <b>:subject</b><br>
	:status in :category, and it has been assigned to you.<br>
',

];
