<?php

return [
    'initial-setup'                   => 'Configuração Inicial dos Chamados',
    'master-template-file'            => 'Arquivo de Modelo Principal',
    'master-template-other-path'      => 'Outro Caminho para o Arquivo de Modelo Principal',
    'master-template-other-path-ex'   => 'ex. views/layouts/app.blade.php',
    'migrations-to-be-installed'      => 'Esta Migração será Instalada:',
    'all-tables-migrated'             => 'Todas as Tabelas serão Migradas',
    'proceed'                         => 'Continuar',
    'another-file'                    => 'Outro Arquivo',
];
