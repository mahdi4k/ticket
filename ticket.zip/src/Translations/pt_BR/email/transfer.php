<?php

return [
    'data' => '<b>:name</b> foi transferido de chamado "<b>:subject</b>" para :agent na :old_category para você na :new_category<br>',
];
