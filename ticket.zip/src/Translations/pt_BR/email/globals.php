<?php

return [
    'assigned'    => 'Chamado Atribuido',
    'comment'     => 'Novo Comentário',
    'status'      => 'Status alterado',
    'transfer'    => 'Chamado Transferido',
    'view-ticket' => 'Click aqui pra ver seu chamado.',
];
