<?php

return [

    'assigned'    => 'Ticket toegewezen',
    'comment'     => 'Nieuwe reactie',
    'status'      => 'Status veranderd',
    'transfer'    => 'Ticket verplaatst',
    'view-ticket' => 'Klik hier om jouw ticket te bekijken.',

];
