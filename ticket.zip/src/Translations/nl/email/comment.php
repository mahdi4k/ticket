<?php

return [

'data' => '
	<b>:name</b> heeft gereageerd op ticket: <b>:subject</b><br>
	<b>Categorie:</b> :category - <b>Status:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];
