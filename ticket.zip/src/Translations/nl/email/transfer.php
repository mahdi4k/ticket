<?php

return [

'data' => '<b>:name</b> heeft ticket "<b>:subject</b>" verplaatst van :agent in :old_category naar jou in :new_category<br>',

];
