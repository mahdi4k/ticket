<?php

return [

'data' => '<b>:name</b> veranderde de status van ":subject" van :old_status naar :new_status<br>',

];
