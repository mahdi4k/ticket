<?php

return [

'data' => '
	<b>:name</b> heeft een ticket aangemaakt, getiteld <b>:subject</b><br>
	:status in :category, en is aan jou toegewezen.<br>
',

];
