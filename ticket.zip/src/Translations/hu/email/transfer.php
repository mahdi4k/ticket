<?php

return [

'data' => '<b>:name</b> átruházta <b>:subject</b> kérelmet :status státusszal :agent ügynöktől önre. Kategória :old_category &#8594; :new_category<br>',

];
