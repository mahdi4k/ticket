<?php

return [

    'assigned'    => 'Kérelem hozzárendelve',
    'comment'     => 'Új hozzászólás',
    'status'      => 'Státusz megváltozott',
    'transfer'    => 'Kérelem átmozgatva',
    'view-ticket' => 'Kattintson ide kérelme megtekintéséhez.',

];
