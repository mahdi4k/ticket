<?php

return [

'data' => '<b>:name</b> megváltoztatta :subject kérelem státuszát: :old_status &#8594; :new_status<br>',

];
