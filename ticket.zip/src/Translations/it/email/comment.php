<?php

return [

'data' => '
	<b>:name</b> ha risposto alla tua richiesta di supporto: <b>:subject</b><br>
	<b>Categoria Ticket:</b> :category - <b>stato:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];
