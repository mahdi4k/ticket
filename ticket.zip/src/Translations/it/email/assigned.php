<?php

return [

'data' => '
	<b>:name</b> ha creato un nuovo ticket di assistenza <b>:subject</b><br>
	:status in :category, ed è stato assegnato a te.<br>
',

];
