<?php

return [

    'data' => '
	<b>:name</b> قام بفتح التذكرة <b>:subject</b><br>
	:status في :category, وتم تعيينه لك.<br>
',

];
