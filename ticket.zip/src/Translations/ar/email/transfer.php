<?php

return [

    'data' => '<b>:name</b> قام بنقل التذكرة "<b>:subject</b>" من :agent في :old_category إليك في :new_category<br>',

];
