<?php

return [

    'assigned'    => 'Tiquete Asignado',
    'comment'     => 'Nuevo Comentario',
    'status'      => 'Estado Cambiado',
    'transfer'    => 'Tiquete Transferido',
    'view-ticket' => 'Haz click aquí para ver su tiquete.',

];
