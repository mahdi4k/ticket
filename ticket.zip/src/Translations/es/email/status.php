<?php

return [

'data' => '<b>:name</b> cambió el estado de ":subject" de :old_status a :new_status<br>',

];
