<?php

return [

'data' => '
	<b>:name</b> comentó en el tiquete: <b>:subject</b><br>
	<b>Categoría del tiquete:</b> :category - <b>estado:</b> :status<br>
	<br>
	<div><b>:comment</b></div><br>
',

];
