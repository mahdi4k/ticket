<?php

return [

'data' => '
	<b>:name</b> creó el tiquete nuevo <b>:subject</b><br>
	:status en :category, y te lo asignaron.<br>
',

];
