<?php

return [

'data' => '<b>:name</b> a modifié le statut du ticket ":subject" de :old_status à :new_status<br>',

];
